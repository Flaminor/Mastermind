package test;

import data_structure.*;

public class Test {
	public static void main(String[] args) {
		System.out.println("\n*** Tests des classes Jeton et Jeton_indice ***");
		Test_Jeton_Jeton_indice.main(args);
		
		System.out.println("\n*** Tests de la classe Jeton_couleur ***");
		Test_Jeton_couleur.main(args);
		
		System.out.println("\n*** Tests de la classe Row ***");
		Test_Row.main(args);
	}
}
